package bridge;

import java.util.List;

public interface ConjuntosFunction {
	
	public List<Integer> fazOperacao(MeusVetores conjuntos);

}
