package decorator;

public interface Divida {
	
	public void exibeDivida();
	public double getValorDivida();

}
