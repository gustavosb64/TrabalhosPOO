package jogo;

public class Vilao extends Personagem{

	public Vilao(String nome, int vida) {
		super(nome, vida);
	}
	
	public Vilao(String nome, int vida, Superpoder superpoder) {
		super(nome, vida, superpoder);
	}
	
}
