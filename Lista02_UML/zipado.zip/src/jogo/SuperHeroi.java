package jogo;

public class SuperHeroi extends Personagem{

	public SuperHeroi(String nome, int vida) {
		super(nome, vida);
	}
	
	public SuperHeroi(String nome, int vida, Superpoder superpoder) {
		super(nome, vida, superpoder);
	}
	
}
