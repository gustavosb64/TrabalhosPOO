package jogo;

public class Main {
	public static void main(String[] args) {
		Personagem heroi = new SuperHeroi("Zuko", 200, new Superpoder("Rajada de fogo", Categoria.FOGO));
	}
}
