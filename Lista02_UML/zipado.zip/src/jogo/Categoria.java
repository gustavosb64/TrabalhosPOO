package jogo;

public enum Categoria {

	AGUA, FOGO, TERRA;
	
}
